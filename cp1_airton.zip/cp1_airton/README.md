# Template para desenvolvimento e entrega do Checkpoint 1

Esse é um guia simples do README e deve ser customizado pelo estudante

**Nome: Eduardo Kenji**

**Turma: 2TDSPI**

**Ano: 2023**

## Objetivo

Avaliar conceitos sobre Modelagem de dados e aprendizado de máquina (ML)

## Descrição do desafio

O desafio era fazer um aprendizado de máquina em que no final nos desse o valor de venda de um carro <
de acordo com suas caracteristicas(atributos).

## Desenvolvimento do projeto

O projeto foi desenvolvido 100% no Jupyter Notebook em python utilizando diversas bibliotecas,
a principal sendo o sklearn.

## Como executar o projeto

Para o projeto rodar sem problemas é recomendado o uso do Jupyter Notebook ou Google Colab,
ambas as ferramentas sendo de graça, também é obrigatório utilizar o arquivo .csv dos conjuntos
de dados utilizados.

## - Quais são os passos a serem realizados para executar o projeto?

1 - Obter o arquivo .csv
2 - Importar as blibliotecas (já estão no código então basta rodar)
3 - Para o código rodar sem problemas é recomendado rodar ele desde o início
para evitar erros que não existem.

- Quais são as dependências do projeto?

## Video Explicativo

- Coloque aqui o link para o seu video explicando como o projeto foi desenvolvido, quais as dificuldades encontradas e qual a solução adotada.

link: https://www.youtube.com/watch?v=xTGF1tkH2TU
